import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appTopsecret]'
})
export class TopsecretDirective {
  el?:ElementRef

  constructor(private elementRef:ElementRef) { 
    this.el = elementRef;

  }
  ngOnInit(){
    this.el!.nativeElement.style.background = "black";
    this.el!.nativeElement.style.color = "black";
  }

}
