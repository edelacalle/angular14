import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TopsecretDirective } from './topsecret.directive';
import { Component, ElementRef } from '@angular/core';

@Component({
  template: `
    <span id="id_test" appTopsecret >Hola Mundo</span>
  `
})
class HostComponent {}

describe('TopsecretDirective', () => {
  let fixture: ComponentFixture<HostComponent>;
  let el: HTMLInputElement;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TopsecretDirective, HostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(HostComponent);
    fixture.detectChanges();
    el = fixture.debugElement.nativeElement.querySelector('span');
  });

  it('Si hay directiva el estilo ha de ser negro y fondo negro', () => {
    expect(el.style.backgroundColor =="black" && el.style.color=="black").toBeTrue()
  });
  
});

