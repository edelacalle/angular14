import { Injectable } from '@angular/core';
import { LoginService } from './login.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GithubService {

  endpoint:string = 'https://api.github.com/users/%%USERNAME%%/repos';
  constructor(private oLogin: LoginService , private oHttp: HttpClient) {}

  getRepos(){
    let url = this.endpoint.replace('%%USERNAME%%', this.oLogin.githubuser())
    return this.oHttp.get(url)
  }

  async isConnect(){
    try {
      let res = await this.getRepos().toPromise()
      return true;
    } catch (error) {
      return false 
    }
  }
}
