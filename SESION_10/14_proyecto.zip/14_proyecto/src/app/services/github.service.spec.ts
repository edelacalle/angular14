import { TestBed } from '@angular/core/testing';
import { GithubService } from './github.service';
import { HttpClientModule } from '@angular/common/http';

describe('GithubService', () => {
  
  
  let service: GithubService;

  /*
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GithubService);
  });
  */

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientModule], providers: [] });
    service = TestBed.inject(GithubService);
  })

  it('¿Hay conexion con Github?', async () => {
      let ok = await service.isConnect();
      expect( ok ).toBeTrue();
  })
  it('Inicio GitHub no hay items', async () => {
      //let kk = await service.getRepos();
      let aData:any  = await service.getRepos().toPromise();
      
      expect( aData.length == 0 ).toBeTrue();
      
    //  expect(service).toBeTruthy();
      //console.log("service eeee", kk)
      
    });
    
  
  it('should be created', () => {
  //  expect(service).toBeTruthy();
    console.log("service eeee", service)
    expect(true).toBeTrue();
  });
  
  
});
