import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class LoginService {
  users = [
    {id:1, email:"uno@dos.es", password:"p1" , github:"edelacalle", name:"Enrique de la Calle"},
    {id:2, email:"dos@dos.es", password:"p2" , github:"Unitech", name:"Otro Usuario"}
  ]

  nPos: number = -1 ; 
  

  constructor() { }

  login(email:string,password:string):boolean{
    this.nPos = this.users.findIndex(r=> r.email == email &&  r.password == password )
    return this.isLogin();
  }
  logout(){
    this.nPos = -1 ; 
  }
  isLogin(){
    return (this.nPos !=-1 )
  }
  me(){
    return (this.isLogin())?this.users[this.nPos]:{}
  }
  username(){
    return (this.isLogin())?this.users[this.nPos]["name"]:"Invitado"
  }
  githubuser(){
    return (this.isLogin())?this.users[this.nPos]["github"]:"guest"
  }
}
