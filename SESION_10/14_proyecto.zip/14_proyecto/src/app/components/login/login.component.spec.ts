import { ComponentFixture, TestBed } from '@angular/core/testing';



import { FormloginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: FormloginComponent;
  let fixture: ComponentFixture<FormloginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormloginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('datos login ok , Boton Login  activado ', () => {
    component.loginForm.controls['email'].setValue('uno@dos.es');
    component.loginForm.controls['password'].setValue('dddd');
    fixture.detectChanges()
    const bLogin = fixture.debugElement.nativeElement.querySelector('#id_blogin');
    expect(bLogin.disabled == true ).toBeFalse();
  });

  it('datos invalidos , Boton Login  desactivado ', () => {
    component.loginForm.controls['email'].setValue('');
    component.loginForm.controls['password'].setValue('');
    fixture.detectChanges()
    const bLogin = fixture.debugElement.nativeElement.querySelector('#id_blogin');
    expect(bLogin.disabled == true ).toBeTrue();
  });

});
