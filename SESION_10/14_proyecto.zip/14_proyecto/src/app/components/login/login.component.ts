import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-formlogin',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class FormloginComponent implements OnInit {

  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', Validators.required)
  });

  lLogin:boolean = false;
  lError:boolean = false;

  constructor(private oServ: LoginService , private router: Router){
  }

  ngOnInit() {
    let aux:any = this.oServ.me();
    this.lLogin = this.oServ.isLogin();
    this.loginForm = new FormGroup({
      email: new FormControl( aux["email"], [Validators.required, Validators.email]),
      password: new FormControl(aux["password"], Validators.required)
    });
  

  }


  onLogin(){

    if (this.loginForm.valid) {
      let lLogin:boolean = this.oServ.login(this.loginForm.value.email ??'' , this.loginForm.value.password??'');
      if(lLogin){
        this.lLogin = true ; 
        this.lError = false;
        this.router.navigate(['/me'])
      }else{
        this.lError = true;
        this.lLogin = false;
      }
    }
  }
  onLogout(){

    this.oServ.logout();
    this.lError = false;
    this.lLogin = false;
  }
}