import { Component, OnInit } from '@angular/core';
import { GithubService } from 'src/app/services/github.service';

@Component({
  selector: 'app-github',
  templateUrl: './github.component.html',
  styleUrls: ['./github.component.css']
})
export class GithubComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'language'];
  dataSource:any = [];
  constructor( private oGit: GithubService) { }

  ngOnInit(): void {
    this.oGit.getRepos().subscribe((data)=>{
      this.dataSource = data;
    })
  }

}
