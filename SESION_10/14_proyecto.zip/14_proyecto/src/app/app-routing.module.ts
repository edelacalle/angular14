import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FormloginComponent } from './components/login/login.component';
import { SecretComponent } from './components/secret/secret.component';
import { GithubComponent } from './components/github/github.component';
import { MeComponent } from './components/me/me.component';


const routes: Routes = [
  {path:'login' , component: FormloginComponent },
  {path:'me' , component: MeComponent },
  {path:'secret', component: SecretComponent},
  {path:'github', component: GithubComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

