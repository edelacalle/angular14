import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormularioComponent } from './formulario.component';

describe('FormularioComponent', () => {

  let component: FormularioComponent;
  let fixture: ComponentFixture<FormularioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormularioComponent ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(FormularioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

    
  it('01. Se creo el Formulario Correctamente', () => {
    expect(component).toBeTruthy();
  });

  it('02. Debe tener un campo titulo en el formulario', () => {
    expect(component.titulo).toEqual('Formulario Alta');
  });

  it('03. Si inputo datos erroneos el form debe invalido', () => {
    component.contactForm.controls['email'].setValue('');
    component.contactForm.controls['password'].setValue('');
    expect(component.contactForm.valid).toBeFalse();
  });

  it('04. si inputo datos correctos el form debe ser valido', () => {
    component.contactForm.controls['email'].setValue('uno@dos.es');
    component.contactForm.controls['password'].setValue('p1');
    expect(component.contactForm.valid).toBeTruthy();
  });


  it('05. Al enviar se debe limpiar el contenido de contacto', () => {
    component.contactForm.controls['email'].setValue('uno@dos.es');
    component.contactForm.controls['password'].setValue('p1');
    fixture.detectChanges()
    const button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();
  
    expect( 
      component.submited      == true   && 
      component.contact.email ==  ""    && 
      component.contact.password  ==  ""  ).toBeTrue()
    
  })
  
});
