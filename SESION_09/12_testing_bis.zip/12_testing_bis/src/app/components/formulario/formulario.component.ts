import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicioService } from 'src/app/services/servicio.service';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {
  titulo:string ='Formulario Alta';
  contactForm!: FormGroup ;
  contact = {
    email:'',
    password:''
  }
  submited:boolean = false;

  constructor( private oServ: ServicioService ) { 
    this.createForm();
  }

  ngOnInit(): void {
    
  }
  createForm():void{
    this.contactForm = new FormGroup({
      'email': new FormControl(this.contact.email,[Validators.required, Validators.email]),
      'password': new FormControl(this.contact.password,[Validators.required])
    });
  }
  envia(){
    let oUser = this.oServ.login(this.contactForm.value.email, this.contactForm.value.password );
    if(oUser){
      this.submited = true ;
      this.contactForm.reset();
      this.titulo = oUser.nombre;
    }else{
      this.titulo = 'Error en Login';
    }
    //console.log("kk es ", kk )
      /*
    console.log( "se ha enviado el contacto ", this.contactForm.value)
    this.submited = true ;
    this.contactForm.reset();
    console.log( "Ahora contact vale ", this.contact)
    */
  }
  onEditButtonClick(){
    console.log("han pulsado test ")
    this.contact={password:"uno", email:"dos"}
  }

}
