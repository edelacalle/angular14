import { TestBed } from '@angular/core/testing';

import { ServicioService } from './servicio.service';


describe('ServicioService', () => {
  let service: ServicioService;
 
  beforeEach(() => {
    TestBed.configureTestingModule({})
    .compileComponents();
 
    service = TestBed.inject(ServicioService);
  });
 


  it('01. Se crea bien el servicio', () => {
    expect(service).toBeTruthy();
  });
  it('02 Debe haber 4 usuarios en el comienzo de la app', () => {
    expect(service.usuarios.length).toEqual(4);
  });

  
  
});
