import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class ServicioService {
  usuarios=[
    {id:1, email:"uno@dos.es"   , password:"p1" , nombre:"Usuario uno"},
    {id:2, email:"dos@dos.es"   , password:"p2" , nombre:"Usuario dos"},
    {id:3, email:"tres@dos.es"  , password:"p3" , nombre:"Usuario tres"},
    {id:4, email:"cuatro@dos.es", password:"p4" , nombre:"Usuario cuatro" },
  ]

  constructor() { 
  }

  login(email:string,pass:string){
    return this.usuarios.find(r=>( r.email==email && r.password == pass) )
  }

}
